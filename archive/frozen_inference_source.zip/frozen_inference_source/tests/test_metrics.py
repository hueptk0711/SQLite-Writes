from __future__ import annotations

import unittest

from nldbwrite_v3.experiments.metrics import error_taxonomy_row, summarize_run


class MetricsTests(unittest.TestCase):
    def test_plan_metrics_and_slices_are_aggregated(self):
        rows = [
            {
                "parse_success": True,
                "plan_validation_success": True,
                "build_success": True,
                "execution_success": True,
                "target_state_correct": True,
                "strict_full_state_correct": True,
                "side_effect": False,
                "source_parse_row_count_exact": True,
                "plan_metrics_available": True,
                "row_count_exact": True,
                "row_coverage": 1.0,
                "row_exact_match": True,
                "cell_value_f1": 1.0,
                "payload_copy_integrity": 1.0,
                "conflict_action_correct": True,
                "conflict_target_exact": True,
                "conflict_update_column_f1": 1.0,
                "conflict_full_exact": True,
                "table_exact": True,
                "target_column_f1": 0.8,
                "slice_labels": ["semi_structured", "batch_large"],
            },
            {
                "parse_success": True,
                "plan_validation_success": True,
                "build_success": True,
                "execution_success": True,
                "target_state_correct": False,
                "strict_full_state_correct": False,
                "side_effect": False,
                "source_parse_row_count_exact": False,
                "plan_metrics_available": True,
                "row_count_exact": False,
                "row_coverage": 0.5,
                "row_exact_match": False,
                "cell_value_f1": 0.5,
                "payload_copy_integrity": 0.5,
                "conflict_action_correct": False,
                "conflict_target_exact": False,
                "conflict_update_column_f1": 0.5,
                "conflict_full_exact": False,
                "table_exact": False,
                "target_column_f1": 0.4,
                "slice_labels": ["semi_structured"],
            },
        ]
        metrics = summarize_run(rows)
        self.assertEqual(metrics["source_parse_row_count_accuracy"], 0.5)
        self.assertEqual(metrics["row_coverage"], 0.75)
        self.assertEqual(metrics["mapping_table_accuracy"], 0.5)
        self.assertAlmostEqual(metrics["target_column_f1"], 0.6)
        self.assertEqual(metrics["cell_value_f1"], 0.75)
        self.assertEqual(
            metrics["slices"]["batch_large"]["target_state_accuracy"],
            1.0,
        )

    def test_error_taxonomy_distinguishes_mapping_and_conflict_target(self):
        mapping = error_taxonomy_row(
            {"parse_success": True, "error_type": "INVALID_FIELD_MAPPING"}
        )
        conflict = error_taxonomy_row(
            {"parse_success": True, "error_type": "INVALID_CONFLICT_TARGET"}
        )
        self.assertEqual(mapping["error_category"], "E5_wrong_mapping")
        self.assertEqual(
            conflict["error_category"],
            "E11_conflict_target_or_mask",
        )
        self.assertEqual(mapping["error_stage"], "source_grounding")
        self.assertEqual(conflict["error_stage"], "interpretation")

    def test_selective_reliability_reports_coverage_and_risk(self):
        metrics = summarize_run(
            [
                {
                    "accepted_output": True,
                    "target_state_correct": True,
                },
                {
                    "accepted_output": True,
                    "target_state_correct": False,
                },
                {
                    "accepted_output": False,
                    "target_state_correct": False,
                },
                {
                    "accepted_output": False,
                    "target_state_correct": False,
                },
            ]
        )
        self.assertEqual(metrics["coverage"], 0.5)
        self.assertEqual(metrics["accepted_output_accuracy"], 0.5)
        self.assertEqual(metrics["abstention_rate"], 0.5)
        self.assertEqual(metrics["selective_risk"], 0.5)


if __name__ == "__main__":
    unittest.main()
