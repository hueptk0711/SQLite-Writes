# Chạy ma trận external holdout cuối trên GPU

Gói này chứa mã `fix2`, bộ external holdout đã đóng băng gồm 300 mẫu,
gold plan, 5 cơ sở dữ liệu mới và toàn bộ bằng chứng QA. Không sửa bất kỳ
file nào trong `data/external_holdout/`, `configs/final/`, prompt, parser,
compiler hoặc evaluator sau khi bắt đầu preflight.

## 1. Điều kiện bắt buộc

- GPU: dùng GPU 0; GPU 1 trên server đang lỗi và không được dùng.
- Mô hình: Qwen2.5-Coder-7B-Instruct snapshot đã dùng ở calibration.
- Python GPU: tái sử dụng virtual environment đã chạy thành công calibration
  fix2; không tạo bản sao virtual environment nếu ổ đĩa còn ít.
- Mã v2: cần cho phương pháp `S-FS-v2-M`.
- Calibration GO: đã nằm trong
  `artifacts/calibration/calibration_go_decision.json`.

## 2. Tải gói từ máy local lên server

Trong PowerShell local:

```powershell
scp `
  ".\gpu_final_bundle_20260731\mp_fs_plus_final_gpu_20260731.tar.gz" `
  ".\gpu_final_bundle_20260731\mp_fs_plus_final_gpu_20260731.tar.gz.sha256" `
  "uet@222.255.250.24:/home/uet/hue_ptk/"
```

## 3. Kiểm tra và giải nén trên server

```bash
cd "$HOME/hue_ptk"
sha256sum -c mp_fs_plus_final_gpu_20260731.tar.gz.sha256
tar -xzf mp_fs_plus_final_gpu_20260731.tar.gz
cd "$HOME/hue_ptk/mp_fs_plus_final_gpu_20260731"
```

Không giải nén đè lên một thư mục đã chạy. Nếu tên thư mục này đã tồn tại,
dừng lại và báo Codex để tạo tên phiên mới.

## 4. Xác định virtual environment GPU đang dùng được

```bash
find "$HOME/hue_ptk" -maxdepth 4 \
  -path "*/.venv_gpu/bin/python" -type f -executable -print
```

Ưu tiên environment của calibration fix2. Ví dụ:

```bash
export NLDB_GPU_VENV="$HOME/hue_ptk/mp_fs_plus_calibration_gpu_fix2_20260729/.venv_gpu"
test -x "$NLDB_GPU_VENV/bin/python" && echo "GPU VENV: OK"
```

Nếu lệnh `find` không trả về environment dùng được thì dừng, không cài lại
ngay vì máy chủ đang thiếu dung lượng.

## 5. Khóa biến môi trường

```bash
export NLDB_MODEL_PATH="$HOME/hue_ptk/hf_cache/hub/models--Qwen--Qwen2.5-Coder-7B-Instruct/snapshots/c03e6d358207e414f1eca0bb1891e29f1db0e242"
export NLDB_V2_SOURCE="$HOME/hue_ptk/paper_v2_20260714/nl_db_write_pipeline/src"
export CUDA_VISIBLE_DEVICES=0
export NLDB_NVIDIA_SMI_ID=0
export HF_HOME="$HOME/hue_ptk/hf_cache"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1

test -d "$NLDB_MODEL_PATH" && echo "MODEL: OK"
test -d "$NLDB_V2_SOURCE/nldbwrite" && echo "V2 SOURCE: OK"
test -x "$NLDB_GPU_VENV/bin/python" && echo "GPU PYTHON: OK"
df -h "$PWD"
nvidia-smi -i 0
```

Phải còn ít nhất 3 GiB trên phân vùng chứa dự án.

## 6. Chạy preflight đúng một lần

```bash
bash scripts/server/preflight_final_gpu.sh \
  2>&1 | tee diagnostics/final_preflight_console.log
```

Chỉ tiếp tục nếu cuối log có `FINAL GPU PREFLIGHT: PASS`. Preflight tạo và
đóng băng `configs/experiments/final_protocol.json`. Chạy lại preflight chỉ
để xác minh cùng một protocol; nếu hash khác, script sẽ dừng.

## 7. Chạy ma trận cuối trong tmux

```bash
tmux new -s mpfs_final300
cd "$HOME/hue_ptk/mp_fs_plus_final_gpu_20260731"

export NLDB_GPU_VENV="$HOME/hue_ptk/mp_fs_plus_calibration_gpu_fix2_20260729/.venv_gpu"
export NLDB_MODEL_PATH="$HOME/hue_ptk/hf_cache/hub/models--Qwen--Qwen2.5-Coder-7B-Instruct/snapshots/c03e6d358207e414f1eca0bb1891e29f1db0e242"
export NLDB_V2_SOURCE="$HOME/hue_ptk/paper_v2_20260714/nl_db_write_pipeline/src"
export CUDA_VISIBLE_DEVICES=0
export NLDB_NVIDIA_SMI_ID=0
export HF_HOME="$HOME/hue_ptk/hf_cache"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1

bash scripts/server/run_final_external_holdout.sh \
  2>&1 | tee diagnostics/final_matrix_console.log
```

Tách khỏi tmux bằng `Ctrl+B`, sau đó nhấn `D`. Quay lại bằng:

```bash
tmux attach -t mpfs_final300
```

Theo dõi từ terminal khác:

```bash
cd "$HOME/hue_ptk/mp_fs_plus_final_gpu_20260731"
tail -f diagnostics/final_matrix_console.log
watch -n 20 nvidia-smi -i 0
```

Script chạy tuần tự 6 phương pháp, kiểm tra đủ 300 dòng cho từng phương pháp,
tạo thống kê McNemar, clustered bootstrap, database-macro bootstrap, hiệu
chỉnh Holm, rồi đóng gói kết quả. Không khởi chạy song song hai ma trận.

## 8. Lấy đường dẫn kết quả

```bash
cd "$HOME/hue_ptk/mp_fs_plus_final_gpu_20260731"
cat artifacts/server/last_final_result_archive.txt
cat artifacts/server/last_final_result_checksum.txt
cat artifacts/reports/final_matrix_summary.md
```

Hai file cần tải về là archive được in ở dòng `RESULT ARCHIVE` và file
`.sha256` tương ứng.
