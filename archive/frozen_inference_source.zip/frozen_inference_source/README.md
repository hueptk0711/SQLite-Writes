# NL-to-DB-Write — MP-FS+ Reference-Based Planning

This is the MP-FS+ development tree copied from
`server_downloads/paper_v3_release_20260726/source/paper_v3_mapping_first`.
The canonical v3 release and its consumed DEV/locked-test evidence remain
unchanged.

The system has two input branches and one shared safety boundary:

```text
semi-structured input -> enumerated collection/schema IDs -> materialization
free-text input       -> enumerated evidence/schema IDs -> materialization
both                  -> hard verifier -> compiler -> transactional preflight
accepted              -> isolated execution -> full post-state evaluation
rejected              -> abstain
```

The LLM never emits JSONPath selectors, database identifiers, constraint
columns, or free-form extracted values in MP-FS+. It selects deterministic
references (`c*`, `s*`, `t*.c*`, `t*.u*`, and `e*`). The materializer copies
source cells or verbatim request spans, applies only declared lossless
normalizations, and records an audit trail.

## Current status

The v3 evidence is preserved as development/diagnostic evidence:

- Frozen development package: 120/120 samples, 187 compiled statements.
- Frozen locked-test package: 677/677 samples, 1,133 compiled statements.
- Development and test have zero sample-ID overlap and zero source-group
  overlap.
- All 677 test samples passed automated parse, schema, build, execution, and
  consistency audits. The separate human-review artifact covers the nine added
  samples; this repository does not claim that all 677 were manually reviewed.
- The Gold-MP oracle passes 677/677 with 100% validation, build, execution,
  target-state, and strict affected-state accuracy.
- The 677-sample MP-FS locked test has already been consumed and informed the
  MP-FS+ design. It is not an untouched final holdout for MP-FS+.
- 94/94 unit tests pass in this working tree, including reference resolution,
  evidence IDs, lossless normalization, transactional preflight, selective
  metrics, matched prompts, calibration allocation, authorship/QA independence,
  holdout metadata gates, and current-bundle runtime-source verification.
- The Qwen2.5-Coder-7B v3 GPU run completed 15/15 generations and parses with
  no truncation or output-limit hits, but a raw-output audit invalidated its
  original technical `pass`: both designated accept probes executed to the
  wrong target state, and the reused editable environment imported package
  code from an earlier bundle. Calibration was kept blocked pending a
  hardened replacement smoke.
- The hardened v4 run fixed both prior target-state errors and proved that
  runtime imports came from the current bundle. Its only failed gate was that
  two correctly abstained ambiguity probes did not emit the intended
  `NEEDS_CLARIFICATION` code. The v5 tree makes this decision deterministic
  from the request language.
- The hardened v5 GPU smoke
  `mp_fs_plus_smoke15_v5_20260727T072146Z` passed every predeclared technical
  gate: 15/15 generation and parsing, zero truncation/output-limit hits, 2/2
  target-state-correct accept probes, 2/2 fail-closed clarification probes,
  and verified current-bundle runtime imports. Independent calibration-data
  construction is now authorized; the smoke remains non-reportable.

No MP-FS+ paper result has been fabricated or inferred from these engineering
tests. Final claims require a new 300-request external holdout on 3-5 unseen
databases, a frozen calibration gate, the full matched method matrix, and the
pre-registered statistical analysis.

## Repository layout

```text
paper_v3_mapping_first/
├── artifacts/
│   ├── audit/
│   ├── environment/
│   ├── manifests/
│   └── reports/
├── configs/
│   ├── baselines/
│   ├── demonstrations/
│   ├── experiments/
│   ├── final/
│   ├── models/
│   └── proposed/
├── data/
│   ├── frozen/
│   │   ├── dev/             # 120 development samples
│   │   └── test/            # 677 locked-test samples
│   ├── external_holdout/    # templates only; no final data yet
│   └── splits/preflight/    # fixed 5- and 20-sample preflights
├── docs/
├── experiments/
│   ├── dev/
│   ├── locked_test/
│   └── robustness/
├── scripts/
│   ├── experiments/
│   └── server/
├── src/nldbwrite_v3/
└── tests/
```

The older flat files directly under `data/frozen/` are retained only as legacy
copies. New commands and protocols use `data/frozen/dev/` and
`data/frozen/test/`.

## Deterministic checks

Run from this directory after installing the development extra:

```powershell
python -m pip install -e ".[dev]"
pytest
python scripts/experiments/run_toy_smoke.py `
  --method mp-fs-plus `
  --output-dir experiments/smoke/toy_mp_fs_plus_mock
```

This is a deterministic end-to-end **mock** smoke test with pre-supplied
model outputs. It verifies the MP-FS+ pipeline and artifacts, but it is not a
model-backed accuracy result. The separate 15-sample Hugging Face v3 GPU run
was invalidated by the strengthened target-state and runtime-source gates.
The v4 run repaired those failures but exposed one remaining reason-code gate.
The v5 run passed every technical gate and authorizes independent
calibration-data construction, not paper claims.

The deterministic core uses the Python standard library. GPU inference uses
the exact versions in `requirements-inference.lock.txt`.

## Frozen data

Development:

```text
data/frozen/dev/dataset_dev_v3.json
data/frozen/dev/dev_ids_v3.txt
data/frozen/dev/gold_write_plans_dev_v3.jsonl
data/frozen/dev/frozen_manifest_dev.json
```

Locked test:

```text
data/frozen/test/dataset_test_v3.json
data/frozen/test/test_ids_v3.txt
data/frozen/test/gold_write_plans_test_v3.jsonl
data/frozen/test/frozen_manifest_test.json
```

Profiles and SQLite databases are external, immutable inputs. Configure them
without relying on a particular relative folder layout:

```powershell
$env:NLDB_PROFILE_DIR = "D:\data\profiles_aug900"
$env:NLDB_DATABASE_ROOT = "D:\data\bird_databases"
$env:NLDB_V2_SOURCE = "D:\paper_v2_current\code\nl_db_write_pipeline"
```

`NLDB_V2_SOURCE` is needed only by `S-FS-v2`. Verify all profile/database
hashes against a frozen manifest before any run:

```powershell
python scripts/server/verify_external_assets.py `
  --manifest data/frozen/dev/frozen_manifest_dev.json
```

## Server preparation

Install and capture the exact server environment:

```powershell
python -m pip install -r requirements-inference.txt
python scripts/server/capture_environment.py `
  --lock requirements-inference.lock.txt `
  --output artifacts/environment/environment_manifest_server.json `
  --require-gpu
$env:NLDB_ENVIRONMENT_MANIFEST = `
  "artifacts/environment/environment_manifest_server.json"
```

The runner rejects Hugging Face inference if the environment manifest is not
`gpu_ready` or was captured against a different dependency lock.

For a local checkpoint, compute the real aggregate SHA-256:

```powershell
python scripts/server/build_model_manifest.py `
  --model-path D:\models\qwen-checkpoint `
  --output artifacts/manifests/model_manifest.json
```

Copy `aggregate_sha256` into `model_hash` in a model config. The runner
recomputes the file hashes before loading the model. For a remote Hugging Face
model, use an immutable 40-character commit revision; tokenizer, chat-template,
model-config, and generation-config identities are also recorded.

## Fair method matrix

| ID | Role |
|---|---|
| D-FS-M | Direct SQL with the matched semantic bank |
| J-FS-M | Record JSON with the matched bank and common compiler |
| S-FS-v2-M | Record JSON with the matched bank and frozen v2 builder |
| MP-FS-M | Original Mapping-First architecture with the matched bank |
| MP-FS+ | Reference-only Mapping-First, lossless materialization, hard verifier, and preflight |
| Gold-MP | Gold Write Plan oracle |

All predictive methods use the same six semantic cases: four semi-structured
and two free-text. The bank is in
`configs/demonstrations/matched_semantic_bank.json`. LLM repair is not part of
the final method matrix; historical repair remains only for negative ablation.

MP-FS-M retains the frozen v3 grounding behavior. MP-FS+ does not rewrite an
ID choice heuristically: an unknown or mismatched reference is a structured
abstention. Declared foreign keys still determine compiler order, while
conflict policy and update masks remain explicit.

Primary metrics include full post-state accuracy, original-request accuracy,
state-changing accuracy, conflict-sensitive accuracy, database-macro accuracy,
accepted-output accuracy, and coverage. Risk and abstention are always
reported with accepted-output accuracy.
`payload_copy_integrity` is an MP provenance diagnostic and is not a
cross-method decision metric. Formal paired significance testing is refused on
development runs unless explicitly requested as exploratory analysis.

## MP-FS+ experiment sequence

The complete protocol is in `docs/MP_FS_PLUS_PROTOCOL.md`. Do not use the
existing 677 samples as a new final holdout.

Development example:

```powershell
python scripts/experiments/run_method.py `
  --stage dev `
  --config configs/final/mp_fs_plus.json `
  --inference-config configs/models/hf_local.example.json `
  --data data/frozen/dev/dataset_dev_v3.json `
  --ids data/frozen/dev/dev_ids_v3.txt `
  --gold-plans data/frozen/dev/gold_write_plans_dev_v3.jsonl `
  --output-dir experiments/dev/mp_fs_plus_dev120
```

Create the independently authored 60-sample calibration data using
`data/calibration/README.md`, resolve
`configs/experiments/calibration_protocol.template.json`, and run the five
calibration methods. Only after every gate passes should code/prompts be
frozen.

Audit the new external dataset before freezing:

```powershell
python scripts/data/audit_external_holdout.py `
  --data data/external_holdout/dataset.json `
  --output artifacts/audit/external_holdout_metadata.json
```

The runner supports `--stage calibration`, `--stage external-holdout`, and
`--stage second-model`. Every run locks the resolved matched demonstration
bank, prompt set, code, data, split, profiles, databases, environment, and
model identity.

## Consumed 677-sample policy

The 677-sample result may be used for development ablations, error transitions,
and clearly labeled post-hoc comparison. It must not be used to claim an
untouched MP-FS+ evaluation. Final inference must use the newly authored,
audited, hash-locked external holdout described above.

See `docs/MP_FS_PLUS_PROTOCOL.md`, `docs/ARCHITECTURE.md`, and
`docs/REVIEW_CHECKLIST.md` for the trust boundaries and remaining gates.
