# Post-hoc second-model robustness

This is not a blind primary result. No prompt or method was tuned from these outputs.

| Method | Target | Execution | Admission coverage | Admitted accuracy | Side effect |
|---|---:|---:|---:|---:|---:|
| D-FS-M | 0.9233 | 0.9533 | 0.9967 | 0.9264 | 0.0000 |
| J-FS-M | 0.8800 | 0.9033 | 0.9033 | 0.9742 | 0.0000 |
| MP-FS+ | 0.5300 | 0.5900 | 0.5900 | 0.8983 | 0.0000 |
