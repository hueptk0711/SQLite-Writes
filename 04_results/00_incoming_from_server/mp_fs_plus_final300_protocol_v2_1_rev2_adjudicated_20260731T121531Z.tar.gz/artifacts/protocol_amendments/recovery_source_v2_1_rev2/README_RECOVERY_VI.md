# Recovery v2.1 rev2 cho MP-FS+ và Gold-MP

## Kết luận

Hai mẫu `final_polar_048` và `final_vaccine_047` không thiếu dung lượng đầu
ra hợp lệ. Chúng sinh tuần tự các tham chiếu cột không hợp lệ đến
`t1.c239`–`t1.c250`, lặp cùng giá trị hàng trăm lần và chạm trần 8192 token.
Tăng trần token, sửa prompt/parser hoặc chạy lại hai mẫu sau khi đã xem
holdout đều không phù hợp.

Recovery v2.1:

- không chạy lại bất kỳ inference GPU nào;
- không sửa raw generation, evaluation hoặc metrics;
- giữ cả hai mẫu trong mẫu số 300;
- tính cả hai là dự đoán sai của `MP-FS+`;
- lưu nguyên `FINAL_RUN_INVALID.json`;
- tạo marker `FINAL_RUN_ADJUDICATED.json` riêng, không giả mạo consumed marker;
- chạy `Gold-MP`, tổng hợp sáu phương pháp và đóng gói đầy đủ bằng chứng;
- yêu cầu công bố đây là reporting amendment hậu nghiệm bảo thủ.

Rev2 còn xác minh lỗi completion gate của Gold-MP: 300 raw row có trạng thái
oracle `not_applicable`, nhưng `generation_status` trong evaluation là `null`.
Gold đã đạt toàn bộ accuracy bằng 1.0 và không có truncation; rev2 công nhận
chính các artifact hiện có, không chạy lại Gold.

## Upload từ PowerShell local

```powershell
cd "D:\paper kltn\text to sql"

$recovery = ".\paper_ready_workspace_20260731\02_code\final_v2_1_failure_adjudication_20260731"

scp `
  "$recovery\mp_fs_plus_final_v2_1_recovery_rev2_20260731.tar.gz" `
  "$recovery\mp_fs_plus_final_v2_1_recovery_rev2_20260731.tar.gz.sha256" `
  "uet@222.255.250.24:/home/uet/hue_ptk/"
```

## Kiểm tra và giải nén trên server

```bash
cd "$HOME/hue_ptk"

sha256sum -c \
  mp_fs_plus_final_v2_1_recovery_rev2_20260731.tar.gz.sha256

test ! -e "$HOME/hue_ptk/mp_fs_plus_final_v2_1_recovery_rev2_20260731" \
  || { echo "STOP: recovery folder đã tồn tại"; exit 2; }

tar -xzf mp_fs_plus_final_v2_1_recovery_rev2_20260731.tar.gz
```

Không xóa hoặc sửa thư mục:

`$HOME/hue_ptk/mp_fs_plus_final_gpu_v2_out8192_20260731`

## Chạy recovery

Không cần GPU. Chạy từ shell thường:

```bash
export NLDB_V2_PROJECT="$HOME/hue_ptk/mp_fs_plus_final_gpu_v2_out8192_20260731"
export NLDB_GPU_VENV="$HOME/hue_ptk/mp_fs_plus_final_gpu_20260731/.venv_gpu"

cd "$HOME/hue_ptk/mp_fs_plus_final_v2_1_recovery_rev2_20260731"

bash scripts/run_recovery_v2_1.sh \
  2>&1 | tee \
  "$NLDB_V2_PROJECT/diagnostics/final_v2_1_recovery_rev2_console.log"
```

Thành công khi cuối log có:

```text
FINAL EXTERNAL-HOLDOUT V2.1 RECOVERY: COMPLETE
GPU INFERENCE RERUN: NONE
GOLD-MP RERUN: NONE; EXISTING 300 ORACLE ROWS VERIFIED
AFFECTED MP-FS+ SAMPLES: 2; RETAINED AND SCORED INCORRECT
```

## Kết quả cần gửi Codex

```bash
cd "$NLDB_V2_PROJECT"

tail -n 180 diagnostics/final_v2_1_recovery_rev2_console.log
cat artifacts/reports/final_matrix_summary.md
cat artifacts/server/last_final_result_archive.txt
cat artifacts/server/last_final_result_checksum.txt
```

Nếu script dừng, không sửa, xóa hoặc chạy inference. Gửi log cho Codex.
