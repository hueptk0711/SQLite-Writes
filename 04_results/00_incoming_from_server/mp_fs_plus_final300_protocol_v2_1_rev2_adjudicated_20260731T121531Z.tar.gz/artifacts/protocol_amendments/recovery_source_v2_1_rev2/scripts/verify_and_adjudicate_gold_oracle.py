from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


EXPECTED_PROTOCOL_SHA256 = (
    "e6bb763334f0b7dcec77523794a20687087fe6f0f62f572cdd3e999b7b48a330"
)
EXPECTED_SOURCE_SHA256 = (
    "79cedcb998f087d6b6b95a9a0199f304463d5e1d83e800f0b6bf04e14f7d1442"
)
RESULT_ROOT = Path(
    "experiments/external_holdout/"
    "final300_qwen25_7b_protocol_v2_out8192_20260731"
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise AssertionError(f"Expected JSON object: {path}")
    return value


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def dump_or_verify(path: Path, payload: dict[str, Any]) -> None:
    if path.exists():
        if load_json(path) != payload:
            raise AssertionError(f"Existing adjudication differs: {path}")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Verify a complete Gold-MP oracle run and correct the null "
            "generation-status completion-gate bug without changing results."
        )
    )
    parser.add_argument("--project-root", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    project = Path(args.project_root).resolve()
    protocol_path = project / "configs/experiments/final_protocol.json"
    assert sha256_file(protocol_path) == EXPECTED_PROTOCOL_SHA256
    source_path = (
        project / "src/nldbwrite_v3/experiments/run_method.py"
    )
    assert sha256_file(source_path) == EXPECTED_SOURCE_SHA256

    gold_root = project / RESULT_ROOT / "gold_mp"
    raw_path = gold_root / "raw_generations.jsonl"
    evaluation_path = gold_root / "evaluation.jsonl"
    metrics_path = gold_root / "metrics.json"
    invalid_path = gold_root / "FINAL_RUN_INVALID.json"
    raw = load_jsonl(raw_path)
    evaluation = load_jsonl(evaluation_path)
    metrics = load_json(metrics_path)
    invalid = load_json(invalid_path)

    assert len(raw) == 300
    assert len(evaluation) == 300
    assert len({str(row["sample_id"]) for row in raw}) == 300
    assert len({str(row["sample_id"]) for row in evaluation}) == 300
    assert {str(row["sample_id"]) for row in raw} == {
        str(row["sample_id"]) for row in evaluation
    }
    assert not (gold_root / "FINAL_RUN_CONSUMED.json").exists()
    assert invalid.get("status") == "invalid"
    assert invalid.get("reason") == "truncation_or_missing_prediction"
    assert invalid.get("truncation_failures") == 0
    assert invalid.get("missing_predictions") == 300
    assert invalid.get("final_protocol_sha256") == EXPECTED_PROTOCOL_SHA256

    assert all(row.get("status") == "not_applicable" for row in raw)
    assert all(row.get("phase") == "oracle" for row in raw)
    assert all(str(row.get("raw_output") or "") == "" for row in raw)
    assert all(row.get("generation_status") is None for row in evaluation)
    assert not any(bool(row.get("input_truncated")) for row in evaluation)
    assert not any(bool(row.get("hit_max_new_tokens")) for row in evaluation)

    required_true = (
        "plan_validation_success",
        "build_success",
        "execution_success",
        "target_state_correct",
        "strict_full_state_correct",
        "accepted_output",
    )
    assert all(row.get("parse_status") == "success" for row in evaluation)
    for field in required_true:
        assert all(row.get(field) is True for row in evaluation), field

    required_one = (
        "parse_success",
        "plan_validation_success",
        "build_success",
        "execution_success",
        "target_state_accuracy",
        "strict_full_state_accuracy",
        "database_macro_accuracy",
    )
    assert metrics.get("samples") == 300
    for field in required_one:
        assert float(metrics.get(field)) == 1.0, field
    assert float(metrics.get("input_truncation_rate")) == 0.0
    assert float(metrics.get("output_limit_hit_rate")) == 0.0

    output = Path(args.output).resolve()
    payload = {
        "status": "frozen_oracle_gate_correction",
        "amendment_id": "gold_oracle_null_status_gate_correction_v2_1_rev2",
        "base_protocol_sha256": EXPECTED_PROTOCOL_SHA256,
        "source_sha256": EXPECTED_SOURCE_SHA256,
        "root_cause": (
            "Gold-MP raw rows correctly use status=not_applicable, but the "
            "oracle evaluation branch leaves generation_status null. The "
            "generic final gate therefore misclassified all 300 complete "
            "oracle rows as missing predictions."
        ),
        "gate_reported_missing_predictions": 300,
        "actual_missing_predictions": 0,
        "verified_rows": 300,
        "verified_metrics": {
            field: metrics.get(field) for field in required_one
        },
        "input_truncation_rate": metrics.get("input_truncation_rate"),
        "output_limit_hit_rate": metrics.get("output_limit_hit_rate"),
        "score_policy": "accept_verified_gold_oracle_as_complete",
        "prediction_artifacts_modified": False,
        "evaluation_artifacts_modified": False,
        "metrics_modified": False,
        "oracle_rerun": False,
        "source_artifacts": {
            "protocol": {
                "path": str(protocol_path),
                "sha256": sha256_file(protocol_path),
            },
            "run_method_source": {
                "path": str(source_path),
                "sha256": sha256_file(source_path),
            },
            "invalid_marker": {
                "path": str(invalid_path),
                "sha256": sha256_file(invalid_path),
            },
            "raw_generations": {
                "path": str(raw_path),
                "sha256": sha256_file(raw_path),
            },
            "evaluation": {
                "path": str(evaluation_path),
                "sha256": sha256_file(evaluation_path),
            },
            "metrics": {
                "path": str(metrics_path),
                "sha256": sha256_file(metrics_path),
            },
            "run_lock": {
                "path": str(gold_root / "run_lock.json"),
                "sha256": sha256_file(gold_root / "run_lock.json"),
            },
            "manifest": {
                "path": str(gold_root / "manifest.json"),
                "sha256": sha256_file(gold_root / "manifest.json"),
            },
        },
        "reporting_requirements": {
            "retain_original_invalid_marker": True,
            "disclose_oracle_completion_gate_bug": True,
            "do_not_describe_as_missing_gold_predictions": True,
        },
    }
    dump_or_verify(output, payload)

    marker_path = gold_root / "FINAL_ORACLE_ADJUDICATED.json"
    marker = {
        "status": "adjudicated_oracle_complete",
        "method_id": "Gold-MP",
        "base_protocol_sha256": EXPECTED_PROTOCOL_SHA256,
        "amendment_id": payload["amendment_id"],
        "adjudication_record": str(output),
        "adjudication_record_sha256": sha256_file(output),
        "verified_rows": 300,
        "target_state_accuracy": 1.0,
        "prediction_artifacts_modified": False,
        "evaluation_artifacts_modified": False,
        "metrics_modified": False,
        "original_invalid_marker_retained": True,
    }
    dump_or_verify(marker_path, marker)

    print(json.dumps(payload, ensure_ascii=False, indent=2))
    print(f"ORACLE ADJUDICATION RECORD: {output}")
    print(f"ORACLE ADJUDICATION MARKER: {marker_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
