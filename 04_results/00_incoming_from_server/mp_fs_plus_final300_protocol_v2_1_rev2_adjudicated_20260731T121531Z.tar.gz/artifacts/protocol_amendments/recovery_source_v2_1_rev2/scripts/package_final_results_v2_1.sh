#!/usr/bin/env bash
set -euo pipefail

if [[ "$#" -ne 3 ]]; then
    echo "usage: $0 PROJECT_ROOT RECOVERY_ROOT RESULT_ROOT"
    exit 2
fi

PROJECT_ROOT="$(cd "$1" && pwd)"
RECOVERY_ROOT="$(cd "$2" && pwd)"
RESULT_ROOT="$3"
cd "$PROJECT_ROOT"

PYTHON="${NLDB_GPU_VENV:-$HOME/hue_ptk/mp_fs_plus_final_gpu_20260731/.venv_gpu}/bin/python"
if [[ ! -x "$PYTHON" ]]; then
    echo "STOP: missing Python: $PYTHON"
    exit 2
fi

ADJUDICATION="artifacts/protocol_amendments/final_output_limit_adjudication_v2_1.json"
ORACLE_ADJUDICATION="artifacts/protocol_amendments/final_gold_oracle_gate_adjudication_v2_1_rev2.json"
RECOVERY_SNAPSHOT="artifacts/protocol_amendments/recovery_source_v2_1_rev2"
for required in \
    "$RESULT_ROOT/d_fs_m" \
    "$RESULT_ROOT/j_fs_m" \
    "$RESULT_ROOT/s_fs_v2_m" \
    "$RESULT_ROOT/mp_fs_m" \
    "$RESULT_ROOT/mp_fs_plus/FINAL_RUN_INVALID.json" \
    "$RESULT_ROOT/mp_fs_plus/FINAL_RUN_ADJUDICATED.json" \
    "$RESULT_ROOT/gold_mp/FINAL_RUN_INVALID.json" \
    "$RESULT_ROOT/gold_mp/FINAL_ORACLE_ADJUDICATED.json" \
    artifacts/reports/final_matrix_results.json \
    artifacts/reports/final_main_table.csv \
    artifacts/reports/final_matrix_summary.md \
    "$ADJUDICATION" \
    "$ORACLE_ADJUDICATION" \
    configs/experiments/final_protocol.json \
    artifacts/server/final_model_manifest.json \
    artifacts/server/hf_final_qwen25_7b_in28672_out8192.json \
    artifacts/protocol_amendments/v1_abort_evidence.json \
    artifacts/protocol_amendments/final_protocol_amendment_v2_out8192.json \
    artifacts/environment/environment_manifest_final_server.json \
    "$RECOVERY_ROOT/BUNDLE_MANIFEST.json"
do
    if [[ ! -e "$required" ]]; then
        echo "STOP: cannot package without $required"
        exit 2
    fi
done

"$PYTHON" - \
    artifacts/reports/final_matrix_results.json \
    "$ADJUDICATION" \
    "$ORACLE_ADJUDICATION" <<'PY_RESULT_GATE'
import json
import sys

report = json.load(open(sys.argv[1], encoding="utf-8"))
adjudication = json.load(open(sys.argv[2], encoding="utf-8"))
oracle = json.load(open(sys.argv[3], encoding="utf-8"))
assert report["report_version"] == 3
assert report["status"] == "pass"
assert report["paper_result_eligible"] is True
assert report["sample_count"] == 300
assert report["method_count"] == 6
assert report["reporting_amendment"]["amendment_id"] == (
    "conservative_failure_adjudication_v2_1"
)
assert report["oracle_gate_adjudication"]["amendment_id"] == (
    "gold_oracle_null_status_gate_correction_v2_1_rev2"
)
assert adjudication["status"] == "frozen_conservative_failure_adjudication"
assert adjudication["affected_sample_ids"] == [
    "final_polar_048",
    "final_vaccine_047",
]
assert adjudication["prediction_artifacts_modified"] is False
assert oracle["status"] == "frozen_oracle_gate_correction"
assert oracle["verified_rows"] == 300
assert oracle["actual_missing_predictions"] == 0
assert oracle["prediction_artifacts_modified"] is False
print("FINAL V2.1 REV2 REPORT: PASS; 300 SAMPLES; 6 METHODS")
PY_RESULT_GATE

if [[ -e "$RECOVERY_SNAPSHOT" ]]; then
    cmp \
        "$RECOVERY_ROOT/BUNDLE_MANIFEST.json" \
        "$RECOVERY_SNAPSHOT/BUNDLE_MANIFEST.json"
else
    mkdir -p "$RECOVERY_SNAPSHOT"
    cp -a "$RECOVERY_ROOT"/. "$RECOVERY_SNAPSHOT"/
fi

mkdir -p dist/results
RUN_ID="mp_fs_plus_final300_protocol_v2_1_rev2_adjudicated_$(date -u +%Y%m%dT%H%M%SZ)"
ARCHIVE="$PROJECT_ROOT/dist/results/${RUN_ID}.tar.gz"

tar -czf "$ARCHIVE" \
    "$RESULT_ROOT" \
    artifacts/reports/final_matrix_results.json \
    artifacts/reports/final_main_table.csv \
    artifacts/reports/final_matrix_summary.md \
    artifacts/calibration/calibration_go_decision.json \
    artifacts/server/final_model_manifest.json \
    artifacts/server/hf_final_qwen25_7b_in28672_out8192.json \
    artifacts/protocol_amendments/v1_abort_evidence.json \
    artifacts/protocol_amendments/final_protocol_amendment_v2_out8192.json \
    "$ADJUDICATION" \
    "$ORACLE_ADJUDICATION" \
    "$RECOVERY_SNAPSHOT" \
    artifacts/environment/environment_manifest_final_server.json \
    artifacts/environment/runtime_source_final_server.json \
    diagnostics/final_asset_preflight.json \
    diagnostics/final_metadata_audit.json \
    diagnostics/final_v2_preflight.sha256 \
    diagnostics/final_v2_preflight_console.log \
    diagnostics/final_v2_matrix_console.log \
    diagnostics/final_v2_d_fs_m.log \
    diagnostics/final_v2_j_fs_m.log \
    diagnostics/final_v2_s_fs_v2_m.log \
    diagnostics/final_v2_mp_fs_m.log \
    diagnostics/final_v2_mp_fs_plus.log \
    diagnostics/final_v2_1_gold_mp.log \
    diagnostics/final_v2_1_recovery_console.log \
    diagnostics/final_v2_1_recovery_rev2_console.log \
    configs/experiments/final_protocol.json \
    data/external_holdout/FINAL_RELEASE_MANIFEST.json \
    data/external_holdout/final_validation_report.json \
    data/external_holdout/SHA256SUMS.txt

sha256sum "$ARCHIVE" > "${ARCHIVE}.sha256"
printf '%s\n' "$ARCHIVE" > artifacts/server/last_final_result_archive.txt
printf '%s\n' "${ARCHIVE}.sha256" > artifacts/server/last_final_result_checksum.txt

echo "RESULT ARCHIVE: $ARCHIVE"
echo "RESULT CHECKSUM: ${ARCHIVE}.sha256"
