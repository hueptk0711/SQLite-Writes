from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit(f"usage: {sys.argv[0]} RECOVERY_ROOT")
    root = Path(sys.argv[1]).resolve()
    manifest_path = root / "BUNDLE_MANIFEST.json"
    with manifest_path.open(encoding="utf-8") as handle:
        manifest = json.load(handle)
    assert manifest["bundle_name"] == (
        "mp_fs_plus_final_v2_1_recovery_rev2_20260731"
    )
    assert manifest["purpose"] == (
        "final_v2_1_rev2_failure_and_oracle_gate_adjudication_recovery"
    )
    entries = manifest["files"]
    assert len(entries) == manifest["file_count_excluding_manifest"]
    for relative, expected in entries.items():
        path = root / relative
        assert path.is_file(), path
        assert path.stat().st_size == expected["size_bytes"], path
        assert sha256_file(path) == expected["sha256"], path
    print(
        "RECOVERY BUNDLE MANIFEST: PASS; "
        f"files={len(entries)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
