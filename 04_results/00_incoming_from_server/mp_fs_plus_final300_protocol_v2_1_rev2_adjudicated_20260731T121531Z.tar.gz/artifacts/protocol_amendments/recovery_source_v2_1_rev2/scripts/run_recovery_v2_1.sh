#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RECOVERY_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PROJECT="${NLDB_V2_PROJECT:-$HOME/hue_ptk/mp_fs_plus_final_gpu_v2_out8192_20260731}"
PYTHON="${NLDB_GPU_VENV:-$HOME/hue_ptk/mp_fs_plus_final_gpu_20260731/.venv_gpu}/bin/python"
EXPECTED_PROTOCOL_SHA256="e6bb763334f0b7dcec77523794a20687087fe6f0f62f572cdd3e999b7b48a330"

if [[ ! -d "$PROJECT" ]]; then
    echo "STOP: missing v2 project: $PROJECT"
    exit 2
fi
if [[ ! -x "$PYTHON" ]]; then
    echo "STOP: missing Python: $PYTHON"
    exit 2
fi

"$PYTHON" "$RECOVERY_ROOT/scripts/verify_recovery_bundle.py" \
    "$RECOVERY_ROOT"

cd "$PROJECT"
export PYTHONUNBUFFERED=1
export PYTHONPATH="$PROJECT/src${PYTHONPATH:+:$PYTHONPATH}"

DATA="data/external_holdout/dataset.final.json"
IDS="data/external_holdout/final_holdout_ids.txt"
GOLD="data/external_holdout/gold_plans.runtime.jsonl"
PROFILE_DIR="data/external_holdout/profiles"
DB_ROOT="data/external_holdout/databases"
ENVIRONMENT_MANIFEST="artifacts/environment/environment_manifest_final_server.json"
FINAL_PROTOCOL="configs/experiments/final_protocol.json"
RESULT_ROOT="experiments/external_holdout/final300_qwen25_7b_protocol_v2_out8192_20260731"
ADJUDICATION="artifacts/protocol_amendments/final_output_limit_adjudication_v2_1.json"
ORACLE_ADJUDICATION="artifacts/protocol_amendments/final_gold_oracle_gate_adjudication_v2_1_rev2.json"
LOCK_DIR="diagnostics/final_v2_1_recovery_rev2.lock"

for required in \
    "$DATA" \
    "$IDS" \
    "$GOLD" \
    "$PROFILE_DIR" \
    "$DB_ROOT" \
    "$ENVIRONMENT_MANIFEST" \
    "$FINAL_PROTOCOL" \
    "$RESULT_ROOT/mp_fs_plus/FINAL_RUN_INVALID.json" \
    "$RECOVERY_ROOT/BUNDLE_MANIFEST.json"
do
    if [[ ! -e "$required" ]]; then
        echo "STOP: missing required path: $required"
        exit 2
    fi
done

actual_protocol_sha256="$(sha256sum "$FINAL_PROTOCOL" | awk '{print $1}')"
if [[ "$actual_protocol_sha256" != "$EXPECTED_PROTOCOL_SHA256" ]]; then
    echo "STOP: final protocol hash mismatch"
    echo "EXPECTED: $EXPECTED_PROTOCOL_SHA256"
    echo "ACTUAL:   $actual_protocol_sha256"
    exit 2
fi

mkdir -p diagnostics artifacts/reports artifacts/protocol_amendments
if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    echo "STOP: another v2.1 recovery appears to be running"
    exit 2
fi
trap 'rmdir "$LOCK_DIR" 2>/dev/null || true' EXIT

echo "STEP 1/4: verify and conservatively adjudicate two MP-FS+ failures"
"$PYTHON" "$RECOVERY_ROOT/scripts/verify_and_adjudicate_output_limits.py" \
    --project-root "$PROJECT" \
    --output "$ADJUDICATION"

echo "STEP 2/4: verify and adjudicate the completed Gold-MP oracle"
GOLD_OUTPUT="$RESULT_ROOT/gold_mp"
if [[ -f "$GOLD_OUTPUT/FINAL_ORACLE_ADJUDICATED.json" ]]
then
    echo "SKIP: Gold-MP oracle adjudication already exists"
elif [[ ! -f "$GOLD_OUTPUT/FINAL_RUN_INVALID.json" ]]
then
    if ! "$PYTHON" scripts/experiments/run_method.py \
        --stage external-holdout \
        --config configs/oracles/gold_mp.json \
        --data "$DATA" \
        --ids "$IDS" \
        --profile-dir "$PROFILE_DIR" \
        --db-root "$DB_ROOT" \
        --gold-plans "$GOLD" \
        --output-dir "$GOLD_OUTPUT" \
        --dependency-lock requirements-inference.lock.txt \
        --environment-manifest "$ENVIRONMENT_MANIFEST" \
        --final-protocol "$FINAL_PROTOCOL" \
        > diagnostics/final_v2_1_gold_mp.log 2>&1
    then
        if [[ ! -f "$GOLD_OUTPUT/FINAL_RUN_INVALID.json" ]]; then
            echo "STOP: Gold-MP failed without the expected gate marker"
            tail -n 160 diagnostics/final_v2_1_gold_mp.log
            exit 1
        fi
    fi
fi

"$PYTHON" "$RECOVERY_ROOT/scripts/verify_and_adjudicate_gold_oracle.py" \
    --project-root "$PROJECT" \
    --output "$ORACLE_ADJUDICATION"

echo "STEP 3/4: build the amended final report"
"$PYTHON" "$RECOVERY_ROOT/scripts/summarize_final_matrix_v2_1.py" \
    --result-root "$RESULT_ROOT" \
    --dataset "$DATA" \
    --ids "$IDS" \
    --protocol "$FINAL_PROTOCOL" \
    --adjudication "$ADJUDICATION" \
    --oracle-adjudication "$ORACLE_ADJUDICATION" \
    --output artifacts/reports/final_matrix_results.json \
    --csv-output artifacts/reports/final_main_table.csv \
    --markdown-output artifacts/reports/final_matrix_summary.md

echo "STEP 4/4: package result and recovery evidence"
bash "$RECOVERY_ROOT/scripts/package_final_results_v2_1.sh" \
    "$PROJECT" \
    "$RECOVERY_ROOT" \
    "$RESULT_ROOT"

echo
echo "FINAL EXTERNAL-HOLDOUT V2.1 RECOVERY: COMPLETE"
echo "GPU INFERENCE RERUN: NONE"
echo "GOLD-MP RERUN: NONE; EXISTING 300 ORACLE ROWS VERIFIED"
echo "AFFECTED MP-FS+ SAMPLES: 2; RETAINED AND SCORED INCORRECT"
