from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any


EXPECTED_PROTOCOL_ID = "mp_fs_plus_external_holdout_v2_out8192"
EXPECTED_PROTOCOL_SHA256 = (
    "e6bb763334f0b7dcec77523794a20687087fe6f0f62f572cdd3e999b7b48a330"
)
EXPECTED_PREDECESSOR_SHA256 = (
    "41eee8d41c2205af9485e03fd654a9a46a28720f78511b61babe1443c7d3820a"
)
RESULT_ROOT = Path(
    "experiments/external_holdout/"
    "final300_qwen25_7b_protocol_v2_out8192_20260731"
)
COMPLETED_METHODS = (
    ("d_fs_m", "D-FS-M"),
    ("j_fs_m", "J-FS-M"),
    ("s_fs_v2_m", "S-FS-v2-M"),
    ("mp_fs_m", "MP-FS-M"),
)
EXPECTED_AFFECTED = {
    "final_polar_048": {
        "input_tokens": 13014,
        "output_tokens": 8192,
        "minimum_output_characters": 30_000,
        "minimum_max_column_reference": 245,
    },
    "final_vaccine_047": {
        "input_tokens": 10916,
        "output_tokens": 8192,
        "minimum_output_characters": 30_000,
        "minimum_max_column_reference": 239,
    },
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise AssertionError(f"Expected a JSON object: {path}")
    return value


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def dump_or_verify(path: Path, payload: dict[str, Any]) -> None:
    if path.exists():
        existing = load_json(path)
        if existing != payload:
            raise AssertionError(f"Existing adjudication differs: {path}")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def require_300_rows(
    method_root: Path,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    raw = load_jsonl(method_root / "raw_generations.jsonl")
    evaluation = load_jsonl(method_root / "evaluation.jsonl")
    assert len(raw) == 300, (method_root, "raw", len(raw))
    assert len(evaluation) == 300, (
        method_root,
        "evaluation",
        len(evaluation),
    )
    assert len({str(row["sample_id"]) for row in raw}) == 300
    assert len({str(row["sample_id"]) for row in evaluation}) == 300
    assert {str(row["sample_id"]) for row in raw} == {
        str(row["sample_id"]) for row in evaluation
    }
    return raw, evaluation


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Conservatively adjudicate the two degenerate MP-FS+ generations "
            "as incorrect without modifying or regenerating predictions."
        )
    )
    parser.add_argument("--project-root", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    project = Path(args.project_root).resolve()
    protocol_path = project / "configs/experiments/final_protocol.json"
    protocol = load_json(protocol_path)
    protocol_sha256 = sha256_file(protocol_path)
    assert protocol.get("status") == "frozen"
    assert protocol.get("protocol_id") == EXPECTED_PROTOCOL_ID
    assert protocol_sha256 == EXPECTED_PROTOCOL_SHA256

    capacity_amendment_path = (
        project
        / "artifacts/protocol_amendments/"
        "final_protocol_amendment_v2_out8192.json"
    )
    capacity_amendment = load_json(capacity_amendment_path)
    assert capacity_amendment.get("status") == (
        "frozen_capacity_only_amendment"
    )
    assert capacity_amendment["predecessor"]["sha256"] == (
        EXPECTED_PREDECESSOR_SHA256
    )
    assert capacity_amendment["successor"]["sha256"] == protocol_sha256

    result_root = project / RESULT_ROOT
    completed: dict[str, Any] = {}
    for slug, method_id in COMPLETED_METHODS:
        method_root = result_root / slug
        marker_path = method_root / "FINAL_RUN_CONSUMED.json"
        marker = load_json(marker_path)
        raw, evaluation = require_300_rows(method_root)
        assert marker.get("status") == "consumed"
        assert marker.get("method_id") == method_id
        assert marker.get("final_protocol_sha256") == protocol_sha256
        assert not any(bool(row.get("input_truncated")) for row in raw)
        assert not any(bool(row.get("hit_max_new_tokens")) for row in raw)
        assert not any(row.get("status") != "success" for row in raw)
        assert not any(
            row.get("generation_status") != "success"
            for row in evaluation
        )
        completed[method_id] = {
            "rows": 300,
            "consumed_marker_sha256": sha256_file(marker_path),
        }

    method_root = result_root / "mp_fs_plus"
    raw, evaluation = require_300_rows(method_root)
    invalid_path = method_root / "FINAL_RUN_INVALID.json"
    invalid = load_json(invalid_path)
    assert invalid == {
        "status": "invalid",
        "reason": "truncation_or_missing_prediction",
        "truncation_failures": 2,
        "missing_predictions": 0,
        "run_lock_sha256": invalid["run_lock_sha256"],
        "final_protocol_sha256": protocol_sha256,
    }
    assert not (method_root / "FINAL_RUN_CONSUMED.json").exists()
    assert not (method_root / "SOURCE_DATABASE_MUTATION.json").exists()

    assert not any(bool(row.get("input_truncated")) for row in raw)
    assert not any(row.get("status") != "success" for row in raw)
    assert not any(bool(row.get("oom_fallback_used")) for row in raw)
    affected_raw = {
        str(row["sample_id"]): row
        for row in raw
        if bool(row.get("hit_max_new_tokens"))
    }
    assert set(affected_raw) == set(EXPECTED_AFFECTED), affected_raw

    evaluation_by_id = {
        str(row["sample_id"]): row for row in evaluation
    }
    assert not any(
        row.get("generation_status") not in {"success", "not_applicable"}
        for row in evaluation
    )

    affected_evidence: list[dict[str, Any]] = []
    for sample_id in sorted(EXPECTED_AFFECTED):
        expected = EXPECTED_AFFECTED[sample_id]
        raw_row = affected_raw[sample_id]
        evaluation_row = evaluation_by_id[sample_id]
        assert raw_row.get("input_tokens") == expected["input_tokens"]
        assert raw_row.get("original_input_tokens") == expected["input_tokens"]
        assert raw_row.get("used_input_tokens") == expected["input_tokens"]
        assert raw_row.get("output_tokens") == expected["output_tokens"]
        assert raw_row.get("input_truncated") is False
        assert raw_row.get("hit_max_new_tokens") is True
        assert raw_row.get("oom_fallback_used") is False

        raw_output = str(raw_row.get("raw_output") or "")
        assert len(raw_output) >= expected["minimum_output_characters"]
        column_references = [
            int(value)
            for value in re.findall(r'"t1\.c(\d+)"', raw_output)
        ]
        assert column_references
        max_column_reference = max(column_references)
        assert max_column_reference >= expected[
            "minimum_max_column_reference"
        ]

        normalized_lines = [
            " ".join(line.split())
            for line in raw_output.splitlines()
            if line.strip()
        ]
        repeated_lines = [
            {"count": count, "line_prefix": line[:160]}
            for line, count in Counter(normalized_lines).most_common(10)
            if count > 1
        ]
        assert repeated_lines

        assert evaluation_row.get("generation_status") == "success"
        assert evaluation_row.get("input_truncated") is False
        assert evaluation_row.get("hit_max_new_tokens") is True
        assert evaluation_row.get("parse_status") == "schema_error"
        assert evaluation_row.get("plan_validation_success") is False
        assert evaluation_row.get("build_success") is False
        assert evaluation_row.get("execution_success") is False
        assert evaluation_row.get("target_state_correct") is False
        assert evaluation_row.get("accepted_output") is False

        affected_evidence.append(
            {
                "sample_id": sample_id,
                "generation_status": raw_row.get("status"),
                "input_tokens": raw_row.get("input_tokens"),
                "output_tokens": raw_row.get("output_tokens"),
                "input_truncated": raw_row.get("input_truncated"),
                "hit_max_new_tokens": raw_row.get("hit_max_new_tokens"),
                "oom_fallback_used": raw_row.get("oom_fallback_used"),
                "raw_output_characters": len(raw_output),
                "raw_output_sha256": hashlib.sha256(
                    raw_output.encode("utf-8")
                ).hexdigest(),
                "max_sequential_column_reference": max_column_reference,
                "repeated_line_evidence": repeated_lines,
                "parse_status": evaluation_row.get("parse_status"),
                "plan_validation_success": evaluation_row.get(
                    "plan_validation_success"
                ),
                "execution_success": evaluation_row.get("execution_success"),
                "target_state_correct": evaluation_row.get(
                    "target_state_correct"
                ),
                "score": "incorrect",
            }
        )

    metrics_path = method_root / "metrics.json"
    metrics = load_json(metrics_path)
    assert metrics.get("samples") == 300
    assert abs(
        float(metrics.get("output_limit_hit_rate")) - (2.0 / 300.0)
    ) < 1e-12
    assert float(metrics.get("input_truncation_rate")) == 0.0

    output = Path(args.output).resolve()
    payload = {
        "status": "frozen_conservative_failure_adjudication",
        "amendment_id": "conservative_failure_adjudication_v2_1",
        "base_protocol_id": EXPECTED_PROTOCOL_ID,
        "base_protocol_sha256": protocol_sha256,
        "rationale": (
            "Two MP-FS+ generations entered deterministic schema-invalid "
            "sequential-reference expansion until the uniform output cap. "
            "All 300 predictions exist, with no input truncation, OOM, or "
            "missing prediction. The two rows remain in the denominator and "
            "are conservatively scored as incorrect."
        ),
        "scope": {
            "method_id": "MP-FS+",
            "affected_count": 2,
            "all_other_methods_changed": False,
        },
        "affected_sample_ids": sorted(EXPECTED_AFFECTED),
        "affected_evidence": affected_evidence,
        "score_policy": "retain_in_denominator_and_score_as_incorrect",
        "generation_policy": {
            "predictions_regenerated": False,
            "prompt_changed": False,
            "parser_changed": False,
            "evaluator_correctness_changed": False,
            "token_limit_increased": False,
            "samples_removed": False,
        },
        "prediction_artifacts_modified": False,
        "completed_before_adjudication": completed,
        "source_artifacts": {
            "base_protocol": {
                "path": str(protocol_path),
                "sha256": protocol_sha256,
            },
            "capacity_amendment": {
                "path": str(capacity_amendment_path),
                "sha256": sha256_file(capacity_amendment_path),
            },
            "invalid_marker": {
                "path": str(invalid_path),
                "sha256": sha256_file(invalid_path),
            },
            "raw_generations": {
                "path": str(method_root / "raw_generations.jsonl"),
                "sha256": sha256_file(
                    method_root / "raw_generations.jsonl"
                ),
            },
            "evaluation": {
                "path": str(method_root / "evaluation.jsonl"),
                "sha256": sha256_file(method_root / "evaluation.jsonl"),
            },
            "metrics": {
                "path": str(metrics_path),
                "sha256": sha256_file(metrics_path),
            },
            "run_lock": {
                "path": str(method_root / "run_lock.json"),
                "sha256": sha256_file(method_root / "run_lock.json"),
            },
            "manifest": {
                "path": str(method_root / "manifest.json"),
                "sha256": sha256_file(method_root / "manifest.json"),
            },
        },
        "reporting_requirements": {
            "disclose_post_run_reporting_amendment": True,
            "report_affected_count": True,
            "do_not_claim_strict_preregistration": True,
            "retain_original_invalid_marker": True,
        },
    }
    dump_or_verify(output, payload)

    marker_path = method_root / "FINAL_RUN_ADJUDICATED.json"
    marker = {
        "status": "adjudicated_as_incorrect",
        "method_id": "MP-FS+",
        "base_protocol_sha256": protocol_sha256,
        "amendment_id": payload["amendment_id"],
        "adjudication_record": str(output),
        "adjudication_record_sha256": sha256_file(output),
        "affected_sample_ids": sorted(EXPECTED_AFFECTED),
        "prediction_artifacts_modified": False,
        "score_policy": payload["score_policy"],
        "original_invalid_marker_retained": True,
    }
    dump_or_verify(marker_path, marker)

    print(json.dumps(payload, ensure_ascii=False, indent=2))
    print(f"ADJUDICATION RECORD: {output}")
    print(f"ADJUDICATION MARKER: {marker_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
