# Conservative failure-adjudication amendment v2.1

The final v2 matrix produced all 300 MP-FS+ raw generations. Two otherwise
successful generation calls (`final_polar_048` and `final_vaccine_047`)
entered schema-invalid sequential-reference expansion and reached the uniform
8192-token output cap. Neither case involved input truncation, OOM fallback,
missing prediction, accepted output, plan validation, execution, or a correct
target state.

No inference is rerun and no prediction, parser, evaluator correctness field,
or metric is modified. Both cases remain in the 300-sample denominator and
are scored as incorrect MP-FS+ predictions. The original invalid marker is
retained, and the exact raw/evaluation/metric hashes are bound into a
machine-readable adjudication record.

Suggested paper disclosure:

> Two MP-FS+ generations entered schema-invalid sequential-reference
> expansion and reached the common output cap. We did not regenerate, repair,
> remove, or increase the token budget for these cases. Both remained in the
> 300-request denominator and were conservatively scored as incorrect. This
> post-run reporting adjudication affects only completion semantics; all raw
> predictions and per-request correctness outcomes are unchanged.

The evaluation should not be described as strictly preregistered without
mentioning this amendment.

## Gold-MP completion-gate correction

Gold-MP produced all 300 oracle rows and achieved 1.0 parse, validation,
build, execution, target-state, strict-state, and database-macro accuracy,
with no truncation or output-limit event. Its raw rows correctly use the
non-generative status `not_applicable`; however, the oracle evaluation branch
left `generation_status` null. The generic completion gate consequently
reported 300 missing predictions. Recovery rev2 verifies and reuses the exact
existing oracle artifacts, retains the original invalid marker, and records a
separate oracle adjudication marker. No oracle output, evaluation, or metric
is regenerated or changed.
